# ArkSwift Product Audit Pipeline

54 seconds · 1920 × 1080 · 30 fps · silent · HyperFrames 0.8.81 + GSAP 3.14.2

## Preview

Run from `C:\code\ArkSwift_Product_Audit_Demo`:

```powershell
npm run dev -- --background --port 3018
```

Open `http://localhost:3018/#project/ArkSwift_Product_Audit_Demo`.

## Render

```powershell
.\render-demo.ps1
```

The script discovers the existing FFmpeg installation and runs:

```powershell
npm run render -- --fps 30 --quality delivery --workers 2 --output renders/ArkSwift_Product_Audit_Demo.mp4
```

## Files

```text
ArkSwift_Product_Audit_Demo/
  assets/                 Supplied PNGs, reference fonts and local GSAP
  index.html              Seekable screenshot walkthrough, main composition
  index.motion.json       Motion assertions
  hyperframes.json         HyperFrames project configuration
  package.json            Pinned preview/check/render commands
  BRIEF.md                Constraints and source-truth decisions
  STORYBOARD.md           Shot timings and copy
  frame.md                Reference ArkSwift visual language
  render-demo.ps1          Reproducible local MP4 render
  work/
    build-demo.mjs        Editable shot data and composition generator
    shot-list.json        Crop rectangles, focus boxes and cursor positions
    check.json            Browser verification report
    frames/               Keyframe snapshots and contact sheets
  renders/
    ArkSwift_Product_Audit_Demo.mp4
```

`npm run build` regenerates the composition. `npm run check -- --samples 12` validates it.

## Timeline

| Time | Scene |
|---|---|
| 0–5s | ArkSwift pending products and manual actions |
| 5–12s | Start audit and track progress |
| 12–23s | Resolution, image roles, dimension match, routing |
| 23–29s | 16 PASS / 9 FAIL / 5 REVIEW |
| 29–41s | Original product evidence, approval and saved rejection reason |
| 41–50s | 20 approvals / 10 rejections, submission log, empty Admin queue |
| 50–54s | ArkSwift ending |

## Fidelity

The source screenshots are unmodified. Editorial text, camera movement, focus outlines and cursor gestures guide attention. Captured states are compressed for pace; the video is not a screen recording of a new live audit.

The supplied idle capture is disconnected and its Run audit control appears disabled; gestures illustrate the intended start sequence. The running capture supplies the actual Connected state. No connected-idle capture was provided.

The supplied manual review capture has no selected reject category. Its corresponding saved screenshot is an APPROVAL, so the video clicks Approve and shows that real saved record. The additional all-resolved screenshot then shows a different product rejected with `Non-compliant Image · 尺寸图`. No dropdown selection or typed reason is fabricated. This replaces the illustrative reject sequence in the original storyboard.

The initial Admin screenshot shows 29 pending while the audit covers 30; no synthetic matching count is claimed. The supplemental final Admin capture shows pending zero. The actual submission log is preserved, including machine rejection evidence.

Architecture, typography, cursor, focus and camera helpers follow the read-only ArkSwift_Demo reference. The new project pins CLI 0.8.81; the old project remains on 0.8.47. Neither the reference project nor the real product source was modified.
