---
duration: 54
music: none
---

## 01 | 0–5s | Every SKU. Manually.

State: animated. Asset: assets/01_arkswift_pending.png. Copy: Every image. Every dimension. Every decision.
Camera: [55,85,1630,996] → [310,330,1350,824]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 02 | 5–8s | One click starts the pipeline.

State: animated. Asset: assets/02_audit_idle.png. Copy: Connect the Admin session, then run the audit.
Camera: [115,5,1445,883] → [115,5,1445,883]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 03 | 8–12s | Track every product.

State: animated. Asset: assets/03_audit_running.png. Copy: Completed count, progress, time per SKU and ETA — in one view.
Camera: [115,5,1445,883] → [135,280,1410,860]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 04 | 12–15s | Check image quality.

State: animated. Asset: assets/03_audit_running.png. Copy: Reject images with either side below 500 px.
Camera: [135,280,1410,860] → [140,290,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 05 | 15–18.5s | Find the right images.

State: animated. Asset: assets/03_audit_running.png. Copy: Dimension images. Usable white backgrounds. Lifestyle candidates.
Camera: [140,290,1015,620] → [140,290,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 06 | 18.5–21s | Match the dimensions.

State: animated. Asset: assets/03_audit_running.png. Copy: Compare normalized OCR measurements with ArkSwift product data.
Camera: [140,290,1015,620] → [140,290,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 07 | 21–23s | Route each result.

State: animated. Asset: assets/03_audit_running.png. Copy: PASS, FAIL or REVIEW.
Camera: [140,290,1015,620] → [140,290,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 08 | 23–26s | Clear cases. Decided.

State: animated. Asset: assets/04_audit_complete.png.png. Copy: 16 pass. 9 fail. Clear cases are decided automatically.
Camera: [140,287,1015,620] → [140,310,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 09 | 26–29s | Only uncertain cases.

State: animated. Asset: assets/04_audit_complete.png.png. Copy: Five products need a human to review the evidence.
Camera: [140,310,1015,620] → [140,420,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 10 | 29–32s | Review the evidence.

State: animated. Asset: assets/05_manual_review.png. Copy: Actual product images, detected roles and ArkSwift facts.
Camera: [-260,0,1940,1185] → [-260,0,1940,1185]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 11 | 32–35s | See what was detected.

State: animated. Asset: assets/05_manual_review.png. Copy: Dimension. White background. Scene candidate.
Camera: [-260,0,1940,1185] → [10,405,865,528]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 12 | 35–37.5s | Approve or reject.

State: animated. Asset: assets/05_manual_review.png. Copy: Rejections require a category and a detailed reason.
Camera: [10,405,865,528] → [10,405,1280,782]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 13 | 37.5–39s | Decision saved.

State: animated. Asset: assets/06_review_resolved.png. Copy: The approved product stays visible in the review queue.
Camera: [132,670,1015,620] → [132,670,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 14 | 39–41s | Reasons stay attached.

State: animated. Asset: assets/06_review_resolved_all.png. Copy: Non-compliant Image — saved with the rejection reason.
Camera: [138,595,1015,620] → [138,595,1015,620]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 15 | 41–45.5s | Apply every decision.

State: animated. Asset: assets/07_apply_decisions.png. Copy: 20 approvals. 10 rejections. Nothing unresolved.
Camera: [115,120,1450,885] → [142,284,1020,623]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 16 | 45.5–48s | Back to ArkSwift.

State: animated. Asset: assets/08_submit_success.png. Copy: Final decisions go through the Admin batch-review workflow.
Camera: [110,120,1450,885] → [1055,645,600,366]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 17 | 48–50s | From audit to action.

State: animated. Asset: assets/08_submit_success2.png. Copy: The ArkSwift pending-review queue is clear.
Camera: [55,80,1630,995] → [55,80,1630,995]; smooth power2.inOut. Focus and cursor positions: work/shot-list.json.

## 18 | 50–54s | Ending

ArkSwift Product Audit Pipeline. Automated checks. Human review when needed.
