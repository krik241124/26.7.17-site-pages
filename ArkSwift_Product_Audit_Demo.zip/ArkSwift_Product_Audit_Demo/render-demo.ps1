$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    $encoder = Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages\Gyan.FFmpeg_*\ffmpeg-*\bin\ffmpeg.exe" -File | Select-Object -First 1
    if (-not $encoder) { throw 'FFmpeg is required to render this project.' }
    $env:PATH = "$($encoder.DirectoryName);$env:PATH"
}
npm run render -- --fps 30 --quality delivery --workers 2 --output renders/ArkSwift_Product_Audit_Demo.mp4
exit $LASTEXITCODE
