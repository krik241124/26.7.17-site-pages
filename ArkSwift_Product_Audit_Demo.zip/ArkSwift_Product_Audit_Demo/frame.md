# ArkSwift reference design

Canvas #0d1b2b; primary text #f5f8fc; secondary #b4c4d8; accent #9fc4ff. Same bundled UI regular/semibold fonts, left editorial column, right 1392×850 screenshot viewport as the reference. One paused GSAP timeline. Screenshot pixels are unmodified. Camera pan/zoom, cursor/ripple, focus outlines and short cross-dissolves.
